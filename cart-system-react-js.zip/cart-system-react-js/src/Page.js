import React from "react";
import { useCart } from "react-use-cart";
import "./page.css";

function Page() {
  const { addItem } = useCart();

  const products = [
    {
      id: 1,
      discountPercentage: 50,
      thumbnail:
        "https://store.storeimages.cdn-apple.com/8756/as-images.apple.com/is/iphone-14-pro-model-unselect-gallery-2-202209?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1660753617559",
      title: "Iphone 14",
      description: "this is iphone 14",
      price: 40,
    },
    {
      id: 2,
      discountPercentage: 50,
      thumbnail:
        "https://www.apple.com/newsroom/images/product/iphone/standard/Apple-iPhone-14-iPhone-14-Plus-hero-220907_Full-Bleed-Image.jpg.large.jpg",
      title: "Iphone 14 pro",
      description: "this is iphone 14 pro",
      price: 40,
    },
    {
      id: 3,
      discountPercentage: 50,
      thumbnail:
        "https://imagedelivery.net/JAV112JY973Crznn4xb8Sg/41816e80-a4b4-47bb-de71-cc19edbfb400/public",
      title: "Iphone 14 pro max",
      description: "this is iphone 14 pro max",
      price: 40,
    },
    {
      id: 4,
      discountPercentage: 50,
      thumbnail:
        "https://www.apple.com/newsroom/images/product/iphone/standard/Apple_iphone13_hero_09142021_inline.jpg.slideshow-xlarge_2x.jpg",
      title: "Iphone 13",
      description: "this is iphone 13",
      price: 40,
    },
    {
      id: 5,
      discountPercentage: 50,
      thumbnail:
        "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-13-finish-select-202207-6-1inch-pink?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1657641867367",
      title: "Iphone 14",
      description: "this is iphone 14",
      price: 40,
    },
    {
      id: 6,
      discountPercentage: 50,
      thumbnail:
        "https://media.wired.com/photos/6148ef98a680b1f2086efee0/1:1/w_1037,h_1037,c_limit/Gear-Review-Apple_iphone13_hero_us_09142021.jpg",
      title: "Iphone 14 pro",
      description: "this is iphone 14 pro",
      price: 40,
    },
    {
      id: 7,
      discountPercentage: 50,
      thumbnail: "https://phoneaqua.com/products/apple-iphone-13-5g.jpg",
      title: "Iphone 14 pro max",
      description: "this is iphone 14 pro max",
      price: 40,
    },
    {
      id: 8,
      discountPercentage: 50,
      thumbnail:
        "https://m.media-amazon.com/images/I/61cpernSJuL._AC_UF1000,1000_QL80_.jpg",
      title: "Iphone 13",
      description: "this is iphone 13",
      price: 40,
    },
  ];
  return (
    <div>
      <nav className="navbar">
        <div className="nav">
          <img
            src="https://pngimg.com/uploads/nike/nike_PNG19.png"
            className="brand-logo"
            alt=""
          />
          <div className="nav-items">
            <div className="search">
              <input
                type="text"
                className="search-box"
                placeholder="search brand, product"
              />
              <button className="search-btn">search</button>
            </div>
            <a href="hello.html">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuQVDZzmYwKrMZsWyCUCfRqP-QK7vHJqTl0gCCqkuu0g&s"
                alt=""
              />
            </a>
            <a href="/Cart">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLcmE3JkfZKyPBR09QM-zrIbfIPVn2fwiN1FtlyaM&s"
                alt=""
              />
            </a>
          </div>
        </div>
      </nav>
      <header className="hero-section">
        <div className="content"></div>
      </header>
      <section className="product">
        <h2 className="product-category">Phones</h2>
        <div className="product-container">
          {products.map((product) => (
            <div key={product.id} className="product-card">
              <div className="product-image">
                {product.discountPercentage && (
                  <span className="discount-tag">
                    {product.discountPercentage}% off
                  </span>
                )}
                <img
                  src={product.thumbnail}
                  className="product-thumb"
                  alt={product.title}
                />
                <button className="card-btn" onClick={() => addItem(product)}>
                  add to cart
                </button>
              </div>
              <div className="product-info">
                <h2 className="product-brand">{product.title}</h2>
                <p className="product-short-des">{product.description}</p>
                {product.discountPercentage ? (
                  <>
                    <span className="price">
                      {(
                        (product.price * (100 - product.discountPercentage)) /
                        100
                      ).toFixed(2)}
                    </span>
                    <span className="actual-price">£{product.price}</span>
                  </>
                ) : (
                  <span className="price">£{product.price}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>
      <footer>
        <p className="footer-title">about company</p>
        <p className="info">
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat
          tempore ad suscipit, eos eius quisquam sed optio nisi quaerat fugiat
          ratione et vero maxime praesentium, architecto minima reiciendis iste
          quo deserunt assumenda alias ducimus. Ullam odit maxime id voluptates
          rerum tenetur corporis laboriosam! Cum error ipsum laborum tempore in
          rerum necessitatibus nostrum nobis modi! Debitis adipisci illum nemo
          aperiam sed, et accusamus ut officiis. Laborum illo exercitationem quo
          culpa reprehenderit excepturi distinctio tempore cupiditate
          praesentium nisi ut iusto, assumenda perferendis facilis voluptas
          autem fuga sunt ab debitis voluptatum harum eum. Asperiores, natus!
          Est deserunt incidunt quasi placeat omnis, itaque harum?
        </p>
        <p className="info">
          support emails - help@clothing.com, customersupport@clothing.com
        </p>
        <p className="info">telephone - 180 00 00 001, 180 00 00 002</p>
        <div className="footer-social-container">
          <div>
            <a href="terms" className="social-link">
              terms & services
            </a>
            <a href="privacy" className="social-link">
              privacy page
            </a>
          </div>
          <div>
            <a href="insta" className="social-link">
              instagram
            </a>
            <a href="fb" className="social-link">
              facebook
            </a>
            <a href="twitter" className="social-link">
              twitter
            </a>
          </div>
        </div>
        <p className="footer-credit">Clothing, Best apparels online store</p>
      </footer>
    </div>
  );
}

export default Page;
