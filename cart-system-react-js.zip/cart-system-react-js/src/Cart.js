import React from "react";
import { useCart } from "react-use-cart";
import "./cart.css";

function Cart() {
  const { isEmpty, totalUniqueItems, items, updateItemQuantity, removeItem } =
    useCart();

  if (isEmpty) return <p>Your cart is empty</p>;

  return (
    <main>
      <div className="basket">
        <div className="basket-labels">
          <ul>
            <li
              className="item item-heading"
              style={{ fontSize: "16px", fontWeight: "bold" }}
            >
              Item
            </li>
            <li
              className="price"
              style={{ fontSize: "16px", fontWeight: "bold" }}
            >
              Price
            </li>
            <li
              className="quantity"
              style={{ fontSize: "16px", fontWeight: "bold" }}
            >
              Quantity
            </li>

            <li
              className="subtotal"
              style={{ fontSize: "16px", fontWeight: "bold" }}
            >
              Subtotal
            </li>
          </ul>
        </div>
        {items.map((item) => (
          <div className="basket-product" key={item.id}>
            <div className="item">
              <div className="product-image">
                <img
                  src={item.thumbnail}
                  alt={item.name}
                  className="product-frame"
                  style={{ width: "200px", height: "200px" }}
                />
              </div>
              {/* <div className="product-details">
                <h1>
                  <strong>
                    <span className="item-quantity">{item.quantity || 0}</span>{" "}
                    x {item.name}
                  </strong>
                </h1>
                <p>
                  <strong>
                    {item.color}, Size {item.size}
                  </strong>
                </p>
                <p>{item.description}</p>
              </div> */}
            </div>
            <div
              className="price"
              style={{ fontSize: "16px", fontWeight: "bold" }}
            >
              {item.price.toFixed(2)}
            </div>
            <div className="quantity">
              <input
                type="number"
                value={item.quantity}
                min="1"
                className="quantity-field"
                onChange={(e) =>
                  updateItemQuantity(item.id, parseInt(e.target.value, 10))
                }
              />
            </div>
            <div className="subtotal">
              {(item.quantity * item.price).toFixed(2)}
            </div>
            <div className="remove">
              <button onClick={() => removeItem(item.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>
      <aside>
        <div className="summary">
          <div className="summary-total-items">
            <span className="total-items">{totalUniqueItems}</span> Items in
            your Bag
          </div>
          <div className="summary-subtotal">
            <div className="subtotal-title">Subtotal</div>
            <div className="subtotal-value final-value" id="basket-subtotal">
              {items
                .reduce((total, item) => total + item.quantity * item.price, 0)
                .toFixed(2)}
            </div>
            <div className="summary-promo hide">
              <div className="promo-title">Promotion</div>
              <div className="promo-value final-value" id="basket-promo"></div>
            </div>
          </div>
          <div className="summary-delivery">
            <select
              name="delivery-collection"
              className="summary-delivery-selection"
            >
              <option value="0" selected="selected">
                Select Collection or Delivery
              </option>
              <option value="collection">Collection</option>
              <option value="first-class">Royal Mail 1st Class</option>
              <option value="second-class">Royal Mail 2nd Class</option>
              <option value="signed-for">Royal Mail Special Delivery</option>
            </select>
          </div>
          <div className="summary-total">
            <div className="total-title">Total</div>
            <div className="total-value final-value" id="basket-total">
              {items
                .reduce((total, item) => total + item.quantity * item.price, 0)
                .toFixed(2)}
            </div>
          </div>
          <div className="summary-checkout">
            <button className="checkout-cta">Go to Secure Checkout</button>
          </div>
        </div>
      </aside>
    </main>
  );
}

export default Cart;
