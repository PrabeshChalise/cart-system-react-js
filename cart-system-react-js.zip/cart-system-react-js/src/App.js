import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"; // Note the changes in imports
import Cart from "./Cart"; // Import the Cart component here
import Page from "./Page"; // Import the Page component here

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Page />} /> {/* ProductPage */}
        <Route path="/cart" element={<Cart />} /> {/* CartPage */}
      </Routes>
    </Router>
  );
}

export default App;
